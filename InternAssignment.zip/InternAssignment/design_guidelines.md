# Stock Data Intelligence Dashboard - Design Guidelines

## Design Approach: Data-Centric Dashboard System
**Framework**: Carbon Design System principles adapted for financial data applications
**References**: Bloomberg Terminal (data density), TradingView (chart clarity), Robinhood (modern simplicity)
**Core Principle**: Information hierarchy through typography, spacing, and component structure - optimized for rapid data scanning and analysis

---

## Layout System

**Structure**: Dashboard split-screen layout
- Left sidebar (w-64 to w-80): Company list with search/filter controls
- Main content area: Full-width chart displays and data tables
- Top navigation bar (h-16): Logo, global filters, user actions

**Spacing Primitives**: Tailwind units of 2, 4, 6, and 8
- Component padding: p-4 to p-6
- Section gaps: gap-6 to gap-8
- Card spacing: space-y-4
- Tight data tables: space-y-2

**Grid System**:
- Metrics cards: grid-cols-2 md:grid-cols-4 (for high/low/avg/volume)
- Stock comparison: grid-cols-1 lg:grid-cols-2 (side-by-side charts)
- Top Gainers/Losers: grid-cols-1 md:grid-cols-2 (split view)

---

## Typography Hierarchy

**Font Family**: Inter or IBM Plex Sans via Google Fonts (optimized for data readability)

**Scale**:
- Page headers: text-2xl font-semibold
- Section titles: text-lg font-medium
- Stock symbols: text-base font-bold uppercase tracking-wide
- Company names: text-sm font-normal
- Metrics labels: text-xs font-medium uppercase tracking-wider
- Metric values: text-3xl font-bold (large numbers) or text-base (regular data)
- Table headers: text-xs font-semibold uppercase
- Table data: text-sm font-mono (for numerical alignment)

**Number Formatting**: Use monospace font (font-mono) for all numerical data to ensure vertical alignment in tables and lists

---

## Component Library

### Navigation & Layout
**Sidebar Company List**:
- Sticky scrollable list with search input at top
- Each item: Company symbol (bold) + name (lighter) + current price
- Active state: subtle shift with indicator line
- Dividers between alphabetical sections

**Top Filter Bar**:
- Horizontal button group for time ranges (30D, 90D, 1Y, All)
- Segmented control pattern for view modes (Chart/Table/Compare)
- Right-aligned refresh button with timestamp

### Data Display Components
**Metric Cards**:
- Compact cards in horizontal grid
- Label at top (small, uppercase)
- Large number value (text-3xl font-bold)
- Percentage change with directional icon (↑/↓)
- Subtle dividing lines between cards

**Data Tables**:
- Sticky headers with sort indicators
- Alternating row treatment for readability
- Right-aligned numerical columns
- Monospace fonts for numbers
- Compact row height (py-2) for data density

**Chart Container**:
- Full-width chart area with aspect-ratio-video
- Chart title with stock symbol prominent
- Legend positioned top-right
- Time axis at bottom, price axis on right
- Generous padding around chart (p-6)

### Interactive Elements
**Stock Comparison Panel**:
- Two-column layout on desktop, stacked on mobile
- Synchronized time range selection
- Side-by-side charts with matching y-axis scales
- Correlation coefficient displayed prominently

**Top Gainers/Losers Section**:
- Compact horizontal cards showing symbol, change %, and sparkline
- Green/red visual treatment through border/background
- Limit to top 5 each for scanning efficiency

**Filter Controls**:
- Button groups with clear active states
- Dropdown for company selection (if not using sidebar)
- Date range picker for custom periods

### Supporting Elements
**Loading States**: Skeleton screens matching component structure
**Empty States**: Clear messaging with suggested actions
**Error States**: Inline error messages near affected components

---

## Responsive Behavior

**Desktop (lg:)**: Full sidebar + main content side-by-side
**Tablet (md:)**: Collapsible sidebar with toggle button, single column for comparisons
**Mobile**: Hidden sidebar accessible via menu, stacked layouts for all grids, simplified metric cards (2-column max)

**Chart Responsiveness**: Maintain readability by adjusting font sizes, reduce data points on mobile if needed, use touch-friendly controls

---

## Animations & Interactions

**Minimize Distractions**: Financial dashboards require focus
- Smooth transitions for view changes (duration-200)
- Subtle hover states on interactive elements
- No auto-playing animations
- Chart rendering: appear with simple fade-in

**Data Updates**: When new data loads, use brief highlight flash on changed values only

---

## Images

**No hero images** - This is a data dashboard, not a marketing site. All visual space dedicated to functional data display and charts.

---

## Accessibility & Usability

**Data Legibility**:
- Minimum font size text-sm for body content
- High contrast ratios for all text
- Clear visual separation between data sections

**Navigation**:
- Keyboard navigation for all interactive elements
- Clear focus indicators on inputs and buttons
- Breadcrumb trail for navigation context

**Screen Reader Support**:
- Proper labeling for all form inputs
- ARIA labels for chart containers
- Semantic HTML for table structures

---

## Quality Standards

This dashboard must convey **professionalism and data credibility**. Every element serves the purpose of efficient financial analysis:
- Dense information presentation without feeling cramped
- Clear visual hierarchy guiding users from overview to details
- Consistent spacing and alignment creating visual rhythm
- Monospace numerics for effortless scanning
- Responsive design maintaining functionality across devices

The result should feel like a professional financial tool - trustworthy, efficient, and focused on delivering insights rapidly.