# Stock Data Intelligence Dashboard

## Overview

This is a full-stack financial analytics platform that provides real-time stock market data and insights for NSE/BSE companies. The application fetches live stock data from Yahoo Finance API, performs advanced analytics calculations (moving averages, volatility scores, correlation analysis), and presents the data through an interactive dashboard with charts, comparison tools, and top movers tracking.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React with TypeScript using Vite as the build tool

**UI Components**: shadcn/ui component library built on Radix UI primitives, styled with Tailwind CSS using a custom design system inspired by Carbon Design System principles and financial dashboard patterns (Bloomberg Terminal data density, TradingView chart clarity, Robinhood modern simplicity)

**State Management**: TanStack Query (React Query) for server state management with automatic caching and background refetching

**Routing**: Wouter for lightweight client-side routing

**Charts**: Chart.js for interactive financial charts with line graphs, moving average overlays, and customizable time ranges

**Design System**: Custom Tailwind configuration with CSS variables for theming, including light/dark mode support, custom color palette for financial data visualization, and monospace fonts for numerical alignment

### Backend Architecture

**Framework**: Express.js with TypeScript running on Node.js

**API Design**: RESTful API with endpoints for companies list, historical stock data, summary statistics, stock comparison, and top movers

**Data Source**: yahoo-finance2 library for fetching real-time and historical stock market data from Yahoo Finance

**Caching Strategy**: In-memory caching with TTL (time-to-live) to reduce API calls and improve performance. Cache keys are structured as `{dataType}:{symbol}:{parameters}` with configurable expiration times (60 seconds for companies list, 5 minutes for stock data)

**Data Processing**: Custom analytics engine that calculates:
- Daily returns: (CLOSE - OPEN) / OPEN
- 7-day and 30-day moving averages
- 52-week high/low tracking
- Volatility scores based on standard deviation
- Correlation coefficients for stock comparison

**Rate Limiting Mitigation**: Sequential processing with 300ms delays between API requests to avoid Yahoo Finance rate limits

### Data Storage

**Current Implementation**: In-memory storage using MemStorage class with no persistent database

**Prepared for Database**: Drizzle ORM configured in drizzle.config.ts for PostgreSQL, with schema definitions in shared/schema.ts ready for database migration when needed

**Storage Interface**: IStorage interface pattern allows easy swapping between in-memory and database implementations without changing business logic

### Design Patterns

**Separation of Concerns**: Clean separation between client (UI), server (API), and shared (types/schemas) directories

**Type Safety**: Zod schemas for runtime validation and TypeScript types derived from schemas for compile-time type checking

**Component Composition**: Reusable UI components (MetricCard, StockChart, TimeRangeFilter, TopMovers) that encapsulate specific functionality

**Data Fetching Pattern**: Custom queryClient configuration with centralized error handling and standardized fetch functions

**Responsive Design**: Mobile-first approach with sidebar that collapses on mobile using Sheet component, adaptive grid layouts (grid-cols-1 md:grid-cols-2 lg:grid-cols-4), and touch-optimized interactions

## External Dependencies

### Third-Party APIs

**Yahoo Finance API** (via yahoo-finance2 npm package):
- Provides real-time stock quotes with price, change, and volume data
- Historical OHLC (Open, High, Low, Close) data with configurable date ranges
- Limited to 10 NSE stocks in current implementation to manage rate limits
- No authentication required but subject to rate limiting

### Core Libraries

**Data Fetching**: yahoo-finance2 v3 for stock market data retrieval

**UI Framework**: React 18 with @tanstack/react-query for server state

**Component Library**: Radix UI primitives (@radix-ui/*) for accessible, unstyled components

**Styling**: Tailwind CSS with custom configuration, class-variance-authority for component variants

**Charts**: Chart.js with react-chartjs-2 wrapper for financial visualizations

**Form Handling**: react-hook-form with @hookform/resolvers for form validation

**Validation**: Zod for schema validation and type generation

**Routing**: wouter for lightweight client-side routing

**Database ORM**: Drizzle ORM with @neondatabase/serverless driver (configured but not actively used)

### Development Tools

**Build Tool**: Vite with TypeScript support and custom plugin configuration

**TypeScript**: Strict mode enabled with path aliases (@/, @shared/, @assets/)

**CSS Processing**: PostCSS with Tailwind CSS and Autoprefixer

**Development Plugins**: Replit-specific plugins for error overlays, cartographer, and dev banners