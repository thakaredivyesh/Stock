import { useState } from "react";
import { Search, TrendingUp } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
} from "@/components/ui/sidebar";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import type { Company } from "@shared/schema";

interface AppSidebarProps {
  companies: Company[];
  isLoading: boolean;
  error?: Error | null;
  refetch?: () => void;
}

export function AppSidebar({ companies, isLoading, error, refetch }: AppSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [location] = useLocation();

  const filteredCompanies = companies.filter(
    (company) =>
      company.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      company.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const isActiveStock = (symbol: string) => location === `/stock/${symbol}`;

  return (
    <Sidebar>
      <SidebarHeader className="p-4 border-b">
        <div className="flex items-center gap-2 mb-4">
          <div className="flex items-center justify-center w-8 h-8 rounded-md bg-primary">
            <TrendingUp className="w-5 h-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-base font-semibold">Stock Intelligence</h1>
            <p className="text-xs text-muted-foreground">NSE/BSE Dashboard</p>
          </div>
        </div>
        <div className="relative">
          <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search stocks..."
            className="pl-8 text-sm"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            data-testid="input-search-stocks"
          />
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-xs font-semibold uppercase tracking-wider">
            Companies ({filteredCompanies.length})
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <SidebarMenuItem key={i}>
                    <div className="px-3 py-2 space-y-2">
                      <Skeleton className="h-4 w-16" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                  </SidebarMenuItem>
                ))
              ) : error ? (
                <div className="px-3 py-8 text-center space-y-2">
                  <p className="text-sm text-muted-foreground">Failed to load companies</p>
                  {refetch && (
                    <button
                      onClick={() => refetch()}
                      className="text-xs text-primary hover:underline"
                      data-testid="button-retry-companies"
                    >
                      Retry
                    </button>
                  )}
                </div>
              ) : filteredCompanies.length === 0 ? (
                <div className="px-3 py-8 text-center">
                  <p className="text-sm text-muted-foreground">No stocks found</p>
                </div>
              ) : (
                filteredCompanies.map((company) => (
                  <SidebarMenuItem key={company.symbol}>
                    <SidebarMenuButton
                      asChild
                      isActive={isActiveStock(company.symbol)}
                      data-testid={`link-stock-${company.symbol}`}
                    >
                      <Link href={`/stock/${company.symbol}`}>
                        <div className="flex flex-col gap-0.5 flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm font-bold uppercase tracking-wide truncate">
                              {company.symbol}
                            </span>
                            {company.changePercent !== undefined && (
                              <Badge
                                variant="outline"
                                className={`text-xs font-mono ${
                                  company.changePercent >= 0
                                    ? "text-green-600 border-green-600/20"
                                    : "text-red-600 border-red-600/20"
                                }`}
                              >
                                {company.changePercent >= 0 ? "+" : ""}
                                {company.changePercent.toFixed(2)}%
                              </Badge>
                            )}
                          </div>
                          <span className="text-xs text-muted-foreground truncate">
                            {company.name}
                          </span>
                          {company.currentPrice !== undefined && (
                            <span className="text-xs font-mono font-medium">
                              ₹{company.currentPrice.toFixed(2)}
                            </span>
                          )}
                        </div>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))
              )}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
