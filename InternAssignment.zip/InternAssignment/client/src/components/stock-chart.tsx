import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from "chart.js";
import { Line } from "react-chartjs-2";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { StockDataPoint } from "@shared/schema";

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
  Filler
);

interface StockChartProps {
  data: StockDataPoint[];
  symbol: string;
  name?: string;
  showMA?: boolean;
}

export function StockChart({ data, symbol, name, showMA = true }: StockChartProps) {
  const chartData = {
    labels: data.map((d) => new Date(d.date).toLocaleDateString("en-US", { month: "short", day: "numeric" })),
    datasets: [
      {
        label: "Close Price",
        data: data.map((d) => d.close),
        borderColor: "hsl(var(--chart-1))",
        backgroundColor: "hsl(var(--chart-1) / 0.1)",
        borderWidth: 2,
        fill: true,
        tension: 0.3,
        pointRadius: 0,
        pointHoverRadius: 5,
        pointBackgroundColor: "hsl(var(--chart-1))",
        pointBorderColor: "#fff",
        pointBorderWidth: 2,
      },
      ...(showMA
        ? [
            {
              label: "7-day MA",
              data: data.map((d) => d.movingAverage7 || null),
              borderColor: "hsl(var(--chart-2))",
              backgroundColor: "transparent",
              borderWidth: 1.5,
              borderDash: [5, 5],
              fill: false,
              tension: 0.3,
              pointRadius: 0,
              pointHoverRadius: 4,
            },
          ]
        : []),
    ],
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: "index" as const,
      intersect: false,
    },
    plugins: {
      legend: {
        display: true,
        position: "top" as const,
        align: "end" as const,
        labels: {
          boxWidth: 12,
          boxHeight: 12,
          padding: 12,
          font: {
            size: 11,
            family: "var(--font-sans)",
          },
          color: "hsl(var(--foreground))",
        },
      },
      tooltip: {
        backgroundColor: "hsl(var(--popover))",
        titleColor: "hsl(var(--popover-foreground))",
        bodyColor: "hsl(var(--popover-foreground))",
        borderColor: "hsl(var(--border))",
        borderWidth: 1,
        padding: 12,
        displayColors: true,
        callbacks: {
          label: function (context: any) {
            let label = context.dataset.label || "";
            if (label) {
              label += ": ";
            }
            if (context.parsed.y !== null) {
              label += "₹" + context.parsed.y.toFixed(2);
            }
            return label;
          },
        },
      },
    },
    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: "hsl(var(--muted-foreground))",
          font: {
            size: 10,
            family: "var(--font-sans)",
          },
          maxRotation: 0,
          autoSkipPadding: 20,
        },
      },
      y: {
        position: "right" as const,
        grid: {
          color: "hsl(var(--border))",
          drawTicks: false,
        },
        ticks: {
          color: "hsl(var(--muted-foreground))",
          font: {
            size: 10,
            family: "var(--font-mono)",
          },
          padding: 8,
          callback: function (value: any) {
            return "₹" + value.toFixed(0);
          },
        },
      },
    },
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg font-medium flex items-baseline gap-3">
          <span className="text-2xl font-semibold uppercase tracking-wide">{symbol}</span>
          {name && <span className="text-sm text-muted-foreground font-normal">{name}</span>}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[400px]" data-testid="chart-stock-price">
          <Line data={chartData} options={options} />
        </div>
      </CardContent>
    </Card>
  );
}
