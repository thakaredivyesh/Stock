import { Button } from "@/components/ui/button";
import type { TimeRange } from "@shared/schema";

interface TimeRangeFilterProps {
  value: TimeRange;
  onChange: (range: TimeRange) => void;
}

const timeRanges: { value: TimeRange; label: string }[] = [
  { value: "30", label: "30D" },
  { value: "90", label: "90D" },
  { value: "365", label: "1Y" },
  { value: "all", label: "All" },
];

export function TimeRangeFilter({ value, onChange }: TimeRangeFilterProps) {
  return (
    <div className="flex gap-1 p-1 rounded-md bg-muted/50" data-testid="filter-time-range">
      {timeRanges.map((range) => (
        <Button
          key={range.value}
          variant={value === range.value ? "secondary" : "ghost"}
          size="sm"
          onClick={() => onChange(range.value)}
          className="text-xs font-medium min-h-8"
          data-testid={`button-time-range-${range.value}`}
        >
          {range.label}
        </Button>
      ))}
    </div>
  );
}
