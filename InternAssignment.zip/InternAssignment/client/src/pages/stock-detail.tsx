import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { StockChart } from "@/components/stock-chart";
import { MetricCard } from "@/components/metric-card";
import { TimeRangeFilter } from "@/components/time-range-filter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, GitCompare } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { StockData, Summary, TimeRange } from "@shared/schema";

export default function StockDetail() {
  const [, params] = useRoute("/stock/:symbol");
  const symbol = params?.symbol || "";
  const [timeRange, setTimeRange] = useState<TimeRange>("90");

  const { data: stockData, isLoading: isLoadingData, error: errorData, refetch: refetchData } = useQuery<StockData>({
    queryKey: ["/api/data", symbol, timeRange],
    queryFn: async () => {
      const res = await fetch(`/api/data/${symbol}?range=${timeRange}`);
      if (!res.ok) throw new Error('Failed to fetch stock data');
      return res.json();
    },
    enabled: !!symbol,
    retry: 2,
    retryDelay: 1000,
  });

  const { data: summary, isLoading: isLoadingSummary, error: errorSummary, refetch: refetchSummary } = useQuery<Summary>({
    queryKey: ["/api/summary", symbol],
    enabled: !!symbol,
    retry: 2,
    retryDelay: 1000,
  });

  if (!symbol) {
    return (
      <div className="flex items-center justify-center h-full">
        <p className="text-muted-foreground">No stock selected</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="icon" data-testid="button-back">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            {isLoadingSummary ? (
              <Skeleton className="h-8 w-32 mb-1" />
            ) : (
              <h1 className="text-2xl font-semibold uppercase tracking-wide">{symbol}</h1>
            )}
            {isLoadingSummary ? (
              <Skeleton className="h-4 w-48" />
            ) : (
              <p className="text-sm text-muted-foreground">{summary?.name}</p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <TimeRangeFilter value={timeRange} onChange={setTimeRange} />
          <Link href={`/compare?symbol1=${symbol}`}>
            <Button variant="outline" size="sm" data-testid="button-compare">
              <GitCompare className="w-4 h-4 mr-2" />
              Compare
            </Button>
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <MetricCard
          label="Current Price"
          value={summary ? `₹${summary.currentPrice.toFixed(2)}` : "—"}
          change={summary?.dailyReturn}
          changeLabel="today"
          isLoading={isLoadingSummary}
          testId="metric-current-price"
        />
        <MetricCard
          label="52W High"
          value={summary ? `₹${summary.high52Week.toFixed(2)}` : "—"}
          isLoading={isLoadingSummary}
          testId="metric-52w-high"
        />
        <MetricCard
          label="52W Low"
          value={summary ? `₹${summary.low52Week.toFixed(2)}` : "—"}
          isLoading={isLoadingSummary}
          testId="metric-52w-low"
        />
        <MetricCard
          label="Volatility"
          value={summary ? summary.volatilityScore.toFixed(2) : "—"}
          isLoading={isLoadingSummary}
          testId="metric-volatility"
        />
      </div>

      {isLoadingData ? (
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-48" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-[400px]" />
          </CardContent>
        </Card>
      ) : errorData ? (
        <Card>
          <CardContent className="py-12">
            <div className="text-center space-y-3">
              <p className="text-muted-foreground">
                Failed to load stock data. Please try again.
              </p>
              <p className="text-xs text-muted-foreground">
                {errorData instanceof Error ? errorData.message : "Unknown error"}
              </p>
              <Button
                variant="outline"
                onClick={() => refetchData()}
                data-testid="button-retry-data"
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : stockData && stockData.data.length > 0 ? (
        <StockChart
          data={stockData.data}
          symbol={symbol}
          name={summary?.name}
          showMA={true}
        />
      ) : (
        <Card>
          <CardContent className="py-12">
            <p className="text-center text-muted-foreground">
              No data available for this stock
            </p>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium">Additional Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Average Close
              </p>
              {isLoadingSummary ? (
                <Skeleton className="h-6 w-24" />
              ) : (
                <p className="text-base font-mono font-semibold">
                  ₹{summary?.averageClose.toFixed(2) || "—"}
                </p>
              )}
            </div>
            <div className="space-y-1">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                7-Day MA
              </p>
              {isLoadingSummary ? (
                <Skeleton className="h-6 w-24" />
              ) : (
                <p className="text-base font-mono font-semibold">
                  ₹{summary?.movingAverage7?.toFixed(2) || "—"}
                </p>
              )}
            </div>
            <div className="space-y-1">
              <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                30-Day MA
              </p>
              {isLoadingSummary ? (
                <Skeleton className="h-6 w-24" />
              ) : (
                <p className="text-base font-mono font-semibold">
                  ₹{summary?.movingAverage30?.toFixed(2) || "—"}
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
