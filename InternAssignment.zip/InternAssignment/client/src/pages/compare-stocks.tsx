import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { StockChart } from "@/components/stock-chart";
import { MetricCard } from "@/components/metric-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import type { Comparison, Company } from "@shared/schema";

export default function CompareStocks() {
  const [location] = useLocation();
  const searchParams = new URLSearchParams(location.split("?")[1] || "");
  const initialSymbol1 = searchParams.get("symbol1") || "";
  const initialSymbol2 = searchParams.get("symbol2") || "";

  const [symbol1, setSymbol1] = useState(initialSymbol1);
  const [symbol2, setSymbol2] = useState(initialSymbol2);

  const { data: companies, isLoading: isLoadingCompanies } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const { data: comparison, isLoading: isLoadingComparison, error: errorComparison, refetch: refetchComparison } = useQuery<Comparison>({
    queryKey: ["/api/compare", symbol1, symbol2],
    queryFn: async () => {
      const res = await fetch(`/api/compare?symbol1=${symbol1}&symbol2=${symbol2}`);
      if (!res.ok) throw new Error('Failed to fetch comparison data');
      return res.json();
    },
    enabled: !!symbol1 && !!symbol2,
    retry: 2,
    retryDelay: 1000,
  });

  useEffect(() => {
    if (initialSymbol1) setSymbol1(initialSymbol1);
    if (initialSymbol2) setSymbol2(initialSymbol2);
  }, [initialSymbol1, initialSymbol2]);

  const canCompare = symbol1 && symbol2 && symbol1 !== symbol2;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Link href="/">
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-semibold">Compare Stocks</h1>
          <p className="text-sm text-muted-foreground">
            Analyze correlation and performance between two stocks
          </p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium">Select Stocks to Compare</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Stock 1
              </label>
              <Select value={symbol1} onValueChange={setSymbol1}>
                <SelectTrigger data-testid="select-stock-1">
                  <SelectValue placeholder="Select first stock" />
                </SelectTrigger>
                <SelectContent>
                  {isLoadingCompanies ? (
                    <div className="p-2">
                      <Skeleton className="h-8 w-full" />
                    </div>
                  ) : (
                    companies?.map((company) => (
                      <SelectItem
                        key={company.symbol}
                        value={company.symbol}
                        disabled={company.symbol === symbol2}
                      >
                        <span className="font-mono font-semibold">{company.symbol}</span>
                        <span className="text-muted-foreground ml-2">— {company.name}</span>
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Stock 2
              </label>
              <Select value={symbol2} onValueChange={setSymbol2}>
                <SelectTrigger data-testid="select-stock-2">
                  <SelectValue placeholder="Select second stock" />
                </SelectTrigger>
                <SelectContent>
                  {isLoadingCompanies ? (
                    <div className="p-2">
                      <Skeleton className="h-8 w-full" />
                    </div>
                  ) : (
                    companies?.map((company) => (
                      <SelectItem
                        key={company.symbol}
                        value={company.symbol}
                        disabled={company.symbol === symbol1}
                      >
                        <span className="font-mono font-semibold">{company.symbol}</span>
                        <span className="text-muted-foreground ml-2">— {company.name}</span>
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {!canCompare ? (
        <Card>
          <CardContent className="py-12">
            <p className="text-center text-muted-foreground">
              Select two different stocks to view comparison
            </p>
          </CardContent>
        </Card>
      ) : isLoadingComparison ? (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <Skeleton className="h-6 w-48" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-24" />
            </CardContent>
          </Card>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[400px]" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <Skeleton className="h-6 w-32" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[400px]" />
              </CardContent>
            </Card>
          </div>
        </div>
      ) : errorComparison ? (
        <Card>
          <CardContent className="py-12">
            <div className="text-center space-y-3">
              <p className="text-muted-foreground">
                Failed to load comparison data. Please try again.
              </p>
              <p className="text-xs text-muted-foreground">
                {errorComparison instanceof Error ? errorComparison.message : "Unknown error"}
              </p>
              <Button
                variant="outline"
                onClick={() => refetchComparison()}
                data-testid="button-retry-comparison"
              >
                Retry
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : comparison ? (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Correlation Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <MetricCard
                  label="Correlation Coefficient"
                  value={comparison.correlation.toFixed(4)}
                  testId="metric-correlation"
                />
                <MetricCard
                  label={`${symbol1} 30D Return`}
                  value={`${comparison.performance1.return30d.toFixed(2)}%`}
                  change={comparison.performance1.return30d}
                  testId="metric-return-1"
                />
                <MetricCard
                  label={`${symbol2} 30D Return`}
                  value={`${comparison.performance2.return30d.toFixed(2)}%`}
                  change={comparison.performance2.return30d}
                  testId="metric-return-2"
                />
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <StockChart
              data={comparison.data1}
              symbol={symbol1}
              name={comparison.name1}
              showMA={false}
            />
            <StockChart
              data={comparison.data2}
              symbol={symbol2}
              name={comparison.name2}
              showMA={false}
            />
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-medium">Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold uppercase tracking-wide">{symbol1}</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">30-Day Return</span>
                      <span className="text-sm font-mono font-semibold">
                        {comparison.performance1.return30d.toFixed(2)}%
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">Volatility</span>
                      <span className="text-sm font-mono font-semibold">
                        {comparison.performance1.volatility.toFixed(4)}
                      </span>
                    </div>
                  </div>
                </div>
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold uppercase tracking-wide">{symbol2}</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">30-Day Return</span>
                      <span className="text-sm font-mono font-semibold">
                        {comparison.performance2.return30d.toFixed(2)}%
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-muted-foreground">Volatility</span>
                      <span className="text-sm font-mono font-semibold">
                        {comparison.performance2.volatility.toFixed(4)}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      ) : (
        <Card>
          <CardContent className="py-12">
            <p className="text-center text-muted-foreground">
              Unable to load comparison data
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
