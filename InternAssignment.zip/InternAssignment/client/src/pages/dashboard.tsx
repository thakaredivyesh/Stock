import { useQuery } from "@tanstack/react-query";
import { TopMovers } from "@/components/top-movers";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { TrendingUp, Activity, BarChart3, Sparkles } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { TopMovers as TopMoversType, Company } from "@shared/schema";

export default function Dashboard() {
  const { data: topMovers, isLoading: isLoadingMovers, error: errorMovers, refetch: refetchMovers } = useQuery<TopMoversType>({
    queryKey: ["/api/top-movers"],
    retry: 2,
    retryDelay: 1000,
  });

  const { data: companies, isLoading: isLoadingCompanies, error: errorCompanies } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
    retry: 2,
    retryDelay: 1000,
  });

  const stats = [
    {
      label: "Total Companies",
      value: companies?.length || 0,
      icon: BarChart3,
      color: "text-blue-600",
    },
    {
      label: "Top Gainers",
      value: topMovers?.gainers.length || 0,
      icon: TrendingUp,
      color: "text-green-600",
    },
    {
      label: "Active Trading",
      value: companies?.length || 0,
      icon: Activity,
      color: "text-purple-600",
    },
    {
      label: "Market Status",
      value: "Open",
      icon: Sparkles,
      color: "text-orange-600",
      isText: true,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h1 className="text-2xl font-semibold">Market Overview</h1>
        <p className="text-sm text-muted-foreground">
          Real-time insights and analytics for NSE/BSE stocks
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    {stat.label}
                  </p>
                  <Icon className={`w-4 h-4 ${stat.color}`} />
                </div>
                {isLoadingCompanies || isLoadingMovers ? (
                  <Skeleton className="h-8 w-16" />
                ) : (
                  <p
                    className={`text-3xl font-bold ${stat.isText ? "" : "font-mono"}`}
                    data-testid={`stat-${stat.label.toLowerCase().replace(/ /g, "-")}`}
                  >
                    {stat.value}
                  </p>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-medium">Welcome to Stock Intelligence Dashboard</CardTitle>
          <CardDescription>
            Explore comprehensive stock data, analytics, and insights for NSE/BSE companies.
            Select a company from the sidebar to view detailed charts and statistics.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-md bg-muted/50">
              <h3 className="text-sm font-medium mb-2">📊 Real-time Data</h3>
              <p className="text-xs text-muted-foreground">
                Access up-to-date stock prices, historical data, and market movements
              </p>
            </div>
            <div className="p-4 rounded-md bg-muted/50">
              <h3 className="text-sm font-medium mb-2">📈 Advanced Analytics</h3>
              <p className="text-xs text-muted-foreground">
                View 7-day moving averages, 52-week statistics, and volatility scores
              </p>
            </div>
            <div className="p-4 rounded-md bg-muted/50">
              <h3 className="text-sm font-medium mb-2">🔍 Compare Stocks</h3>
              <p className="text-xs text-muted-foreground">
                Analyze correlation and performance between any two stocks
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium">Market Movers</h2>
          {errorMovers && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetchMovers()}
              data-testid="button-retry-movers"
            >
              Retry
            </Button>
          )}
        </div>
        {errorMovers ? (
          <Card>
            <CardContent className="py-12">
              <div className="text-center space-y-3">
                <p className="text-muted-foreground">Failed to load market movers</p>
                <p className="text-xs text-muted-foreground">
                  {errorMovers instanceof Error ? errorMovers.message : "Unknown error"}
                </p>
                <Button
                  variant="outline"
                  onClick={() => refetchMovers()}
                  data-testid="button-retry-movers-inline"
                >
                  Try Again
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <TopMovers
            gainers={topMovers?.gainers || []}
            losers={topMovers?.losers || []}
            isLoading={isLoadingMovers}
          />
        )}
      </div>
    </div>
  );
}
