import type {
  Company,
  StockData,
  Summary,
  Comparison,
  TopMovers,
  StockDataPoint,
} from "@shared/schema";

export interface IStorage {
  getCompanies(): Promise<Company[]>;
  getStockData(symbol: string, days?: number): Promise<StockData | null>;
  getSummary(symbol: string): Promise<Summary | null>;
  getComparison(symbol1: string, symbol2: string): Promise<Comparison | null>;
  getTopMovers(): Promise<TopMovers>;
  cacheData(key: string, data: any, ttl?: number): void;
  getCachedData(key: string): any | null;
}

export class MemStorage implements IStorage {
  private cache: Map<string, { data: any; expiry: number }>;

  constructor() {
    this.cache = new Map();
  }

  cacheData(key: string, data: any, ttl: number = 300000): void {
    const expiry = Date.now() + ttl;
    this.cache.set(key, { data, expiry });
  }

  getCachedData(key: string): any | null {
    const cached = this.cache.get(key);
    if (!cached) return null;
    if (Date.now() > cached.expiry) {
      this.cache.delete(key);
      return null;
    }
    return cached.data;
  }

  async getCompanies(): Promise<Company[]> {
    return [];
  }

  async getStockData(symbol: string, days?: number): Promise<StockData | null> {
    return null;
  }

  async getSummary(symbol: string): Promise<Summary | null> {
    return null;
  }

  async getComparison(symbol1: string, symbol2: string): Promise<Comparison | null> {
    return null;
  }

  async getTopMovers(): Promise<TopMovers> {
    return {
      gainers: [],
      losers: [],
      lastUpdated: new Date().toISOString(),
    };
  }
}

export const storage = new MemStorage();
