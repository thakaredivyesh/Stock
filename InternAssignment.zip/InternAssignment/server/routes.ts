import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  fetchCompaniesWithPrices,
  fetchHistoricalData,
  calculateSummary,
  compareStocks,
  fetchTopMovers,
} from "./utils/stock-data";

export async function registerRoutes(app: Express): Promise<Server> {
  // GET /api/companies - Returns list of all available companies with current prices
  app.get("/api/companies", async (req, res) => {
    try {
      const cacheKey = "companies";
      const cached = storage.getCachedData(cacheKey);

      if (cached) {
        return res.json(cached);
      }

      const companies = await fetchCompaniesWithPrices();
      storage.cacheData(cacheKey, companies, 60000); // Cache for 1 minute
      res.json(companies);
    } catch (error) {
      console.error("Error fetching companies:", error);
      res.status(500).json({ error: "Failed to fetch companies" });
    }
  });

  // GET /api/data/:symbol - Returns historical data for a specific stock
  app.get("/api/data/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;
      const range = req.query.range as string;

      // Normalize symbol by removing exchange suffix for consistent caching
      const normalizedSymbol = symbol.replace(".NS", "");

      let days = 90;
      if (range === "30") days = 30;
      else if (range === "90") days = 90;
      else if (range === "365") days = 365;
      else if (range === "all") days = 1825; // ~5 years

      const cacheKey = `data:${normalizedSymbol}:${days}`;
      const cached = storage.getCachedData(cacheKey);

      if (cached) {
        return res.json(cached);
      }

      const data = await fetchHistoricalData(symbol, days);

      const response = {
        symbol: normalizedSymbol,
        data,
      };

      storage.cacheData(cacheKey, response, 300000); // Cache for 5 minutes
      res.json(response);
    } catch (error) {
      console.error(`Error fetching data for ${req.params.symbol}:`, error);
      res.status(500).json({ error: "Failed to fetch stock data" });
    }
  });

  // GET /api/summary/:symbol - Returns summary statistics for a stock
  app.get("/api/summary/:symbol", async (req, res) => {
    try {
      const { symbol } = req.params;

      // Normalize symbol by removing exchange suffix for consistent caching
      const normalizedSymbol = symbol.replace(".NS", "");
      const cacheKey = `summary:${normalizedSymbol}`;
      const cached = storage.getCachedData(cacheKey);

      if (cached) {
        return res.json(cached);
      }

      const summary = await calculateSummary(symbol);

      if (!summary) {
        return res.status(404).json({ error: "Stock not found" });
      }

      storage.cacheData(cacheKey, summary, 300000); // Cache for 5 minutes
      res.json(summary);
    } catch (error) {
      console.error(`Error fetching summary for ${req.params.symbol}:`, error);
      res.status(500).json({ error: "Failed to fetch summary" });
    }
  });

  // GET /api/compare - Compare two stocks
  app.get("/api/compare", async (req, res) => {
    try {
      const { symbol1, symbol2 } = req.query;

      if (!symbol1 || !symbol2) {
        return res.status(400).json({ error: "Both symbol1 and symbol2 are required" });
      }

      // Normalize symbols by removing exchange suffix for consistent caching
      const normalizedSymbol1 = (symbol1 as string).replace(".NS", "");
      const normalizedSymbol2 = (symbol2 as string).replace(".NS", "");
      const cacheKey = `compare:${normalizedSymbol1}:${normalizedSymbol2}`;
      const cached = storage.getCachedData(cacheKey);

      if (cached) {
        return res.json(cached);
      }

      const comparison = await compareStocks(symbol1 as string, symbol2 as string);

      if (!comparison) {
        return res.status(404).json({ error: "Unable to compare stocks" });
      }

      storage.cacheData(cacheKey, comparison, 300000); // Cache for 5 minutes
      res.json(comparison);
    } catch (error) {
      console.error(
        `Error comparing ${req.query.symbol1} and ${req.query.symbol2}:`,
        error
      );
      res.status(500).json({ error: "Failed to compare stocks" });
    }
  });

  // GET /api/top-movers - Returns top gainers and losers
  app.get("/api/top-movers", async (req, res) => {
    try {
      const cacheKey = "top-movers";
      const cached = storage.getCachedData(cacheKey);

      if (cached) {
        return res.json(cached);
      }

      const movers = await fetchTopMovers();

      const response = {
        gainers: movers.gainers,
        losers: movers.losers,
        lastUpdated: new Date().toISOString(),
      };

      storage.cacheData(cacheKey, response, 60000); // Cache for 1 minute
      res.json(response);
    } catch (error) {
      console.error("Error fetching top movers:", error);
      res.status(500).json({ error: "Failed to fetch top movers" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
