import YahooFinance from "yahoo-finance2";
import type { StockDataPoint, Company, Summary, Comparison, TopMover } from "@shared/schema";

// Initialize yahoo-finance2 v3 instance
const yahooFinance = new YahooFinance();

// Popular NSE stocks with .NS suffix for Yahoo Finance
// Limited to 10 for MVP to avoid rate limiting issues while still demonstrating functionality
const NSE_STOCKS = [
  { symbol: "RELIANCE.NS", name: "Reliance Industries Ltd" },
  { symbol: "TCS.NS", name: "Tata Consultancy Services Ltd" },
  { symbol: "HDFCBANK.NS", name: "HDFC Bank Ltd" },
  { symbol: "INFY.NS", name: "Infosys Ltd" },
  { symbol: "ICICIBANK.NS", name: "ICICI Bank Ltd" },
  { symbol: "ITC.NS", name: "ITC Ltd" },
  { symbol: "SBIN.NS", name: "State Bank of India" },
  { symbol: "BHARTIARTL.NS", name: "Bharti Airtel Ltd" },
  { symbol: "KOTAKBANK.NS", name: "Kotak Mahindra Bank Ltd" },
  { symbol: "LT.NS", name: "Larsen & Toubro Ltd" },
];

// Helper to delay between requests to avoid rate limiting
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export function getAvailableCompanies(): { symbol: string; name: string }[] {
  return NSE_STOCKS;
}

export async function fetchCompaniesWithPrices(): Promise<Company[]> {
  const companies: Company[] = [];

  // Process sequentially to avoid rate limiting
  for (const stock of NSE_STOCKS) {
    try {
      await delay(300); // Wait 300ms between each request
      const quote = await yahooFinance.quote(stock.symbol);
      companies.push({
        symbol: stock.symbol.replace(".NS", ""),
        name: stock.name,
        exchange: "NSE",
        currentPrice: quote.regularMarketPrice,
        change: quote.regularMarketChange,
        changePercent: quote.regularMarketChangePercent,
      });
    } catch (error) {
      console.error(`Error fetching quote for ${stock.symbol}:`, error);
      // Return stock with basic info but no price data
      companies.push({
        symbol: stock.symbol.replace(".NS", ""),
        name: stock.name,
        exchange: "NSE",
      });
    }
  }

  return companies;
}

export async function fetchHistoricalData(
  symbol: string,
  days: number = 90
): Promise<StockDataPoint[]> {
  const yahooSymbol = symbol.includes(".NS") ? symbol : `${symbol}.NS`;
  const period2 = new Date();
  const period1 = new Date();
  period1.setDate(period1.getDate() - days);

  try {
    const result = await yahooFinance.historical(yahooSymbol, {
      period1: period1.toISOString().split("T")[0],
      period2: period2.toISOString().split("T")[0],
      interval: "1d",
    });

    if (!result || result.length === 0) {
      console.warn(`No historical data available for ${yahooSymbol}`);
      return [];
    }

    const data: StockDataPoint[] = result.map((item, index) => {
      const dailyReturn =
        item.open && item.close ? ((item.close - item.open) / item.open) * 100 : 0;

      let movingAverage7: number | undefined;
      if (index >= 6) {
        const last7 = result.slice(index - 6, index + 1);
        movingAverage7 =
          last7.reduce((sum, d) => sum + (d.close || 0), 0) / last7.length;
      }

      return {
        date: item.date.toISOString().split("T")[0],
        open: item.open || 0,
        high: item.high || 0,
        low: item.low || 0,
        close: item.close || 0,
        volume: item.volume || 0,
        dailyReturn,
        movingAverage7,
      };
    });

    return data;
  } catch (error) {
    console.error(`Error fetching historical data for ${yahooSymbol}:`, error);
    return [];
  }
}

export async function calculateSummary(symbol: string): Promise<Summary | null> {
  try {
    const [data, quote] = await Promise.all([
      fetchHistoricalData(symbol, 365),
      (async () => {
        try {
          await delay(200);
          const yahooSymbol = symbol.includes(".NS") ? symbol : `${symbol}.NS`;
          return await yahooFinance.quote(yahooSymbol);
        } catch (err) {
          console.error(`Error fetching quote for summary:`, err);
          return null;
        }
      })(),
    ]);

    if (data.length === 0) {
      console.warn(`No data available for summary of ${symbol}`);
      return null;
    }

    const cleanSymbol = symbol.replace(".NS", "");
    const company = NSE_STOCKS.find((s) => s.symbol.replace(".NS", "") === cleanSymbol || s.symbol === symbol);

    const closes = data.map((d) => d.close);
    const high52Week = Math.max(...closes);
    const low52Week = Math.min(...closes);
    const averageClose = closes.reduce((a, b) => a + b, 0) / closes.length;

    const returns = data.map((d) => d.dailyReturn || 0);
    const avgReturn = returns.reduce((a, b) => a + b, 0) / returns.length;
    const variance =
      returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length;
    const volatilityScore = Math.sqrt(variance);

    const last30Days = data.slice(-30);
    const movingAverage7 = last30Days.length >= 7
      ? last30Days.slice(-7).reduce((sum, d) => sum + d.close, 0) / 7
      : undefined;

    const movingAverage30 = last30Days.length >= 30
      ? last30Days.reduce((sum, d) => sum + d.close, 0) / 30
      : undefined;

    const latestData = data[data.length - 1];
    const data30DaysAgo = data[data.length - Math.min(30, data.length)];
    const priceChange30d = data30DaysAgo
      ? latestData.close - data30DaysAgo.close
      : undefined;
    const priceChangePercent30d =
      data30DaysAgo && data30DaysAgo.close > 0
        ? ((latestData.close - data30DaysAgo.close) / data30DaysAgo.close) * 100
        : undefined;

    const currentPrice = quote?.regularMarketPrice ?? latestData.close;

    return {
      symbol: cleanSymbol,
      name: company?.name || cleanSymbol,
      currentPrice,
      high52Week,
      low52Week,
      averageClose,
      totalVolume: data.reduce((sum, d) => sum + d.volume, 0),
      volatilityScore,
      dailyReturn: latestData.dailyReturn || 0,
      movingAverage7,
      movingAverage30,
      priceChange30d,
      priceChangePercent30d,
    };
  } catch (error) {
    console.error(`Error calculating summary for ${symbol}:`, error);
    return null;
  }
}

function calculateCorrelation(data1: number[], data2: number[]): number {
  const n = Math.min(data1.length, data2.length);
  if (n === 0) return 0;

  const mean1 = data1.slice(0, n).reduce((a, b) => a + b, 0) / n;
  const mean2 = data2.slice(0, n).reduce((a, b) => a + b, 0) / n;

  let numerator = 0;
  let sum1Sq = 0;
  let sum2Sq = 0;

  for (let i = 0; i < n; i++) {
    const diff1 = data1[i] - mean1;
    const diff2 = data2[i] - mean2;
    numerator += diff1 * diff2;
    sum1Sq += diff1 * diff1;
    sum2Sq += diff2 * diff2;
  }

  const denominator = Math.sqrt(sum1Sq * sum2Sq);
  return denominator === 0 ? 0 : numerator / denominator;
}

export async function compareStocks(
  symbol1: string,
  symbol2: string
): Promise<Comparison | null> {
  try {
    await delay(200);
    const [data1, data2] = await Promise.all([
      fetchHistoricalData(symbol1, 90),
      fetchHistoricalData(symbol2, 90),
    ]);

    if (data1.length === 0 || data2.length === 0) {
      console.warn(`Insufficient data to compare ${symbol1} and ${symbol2}`);
      return null;
    }

    const yahooSymbol1 = symbol1.includes(".NS") ? symbol1 : `${symbol1}.NS`;
    const yahooSymbol2 = symbol2.includes(".NS") ? symbol2 : `${symbol2}.NS`;

    const company1 = NSE_STOCKS.find((s) => s.symbol === yahooSymbol1 || s.symbol.replace(".NS", "") === symbol1);
    const company2 = NSE_STOCKS.find((s) => s.symbol === yahooSymbol2 || s.symbol.replace(".NS", "") === symbol2);

    const minLength = Math.min(data1.length, data2.length);
    const alignedData1 = data1.slice(-minLength);
    const alignedData2 = data2.slice(-minLength);

    const closes1 = alignedData1.map((d) => d.close);
    const closes2 = alignedData2.map((d) => d.close);
    const correlation = calculateCorrelation(closes1, closes2);

    const returns1 = alignedData1.map((d) => d.dailyReturn || 0);
    const returns2 = alignedData2.map((d) => d.dailyReturn || 0);

    const return30d1 = returns1.reduce((a, b) => a + b, 0);
    const return30d2 = returns2.reduce((a, b) => a + b, 0);

    const avgReturn1 = returns1.reduce((a, b) => a + b, 0) / returns1.length;
    const avgReturn2 = returns2.reduce((a, b) => a + b, 0) / returns2.length;

    const variance1 =
      returns1.reduce((sum, r) => sum + Math.pow(r - avgReturn1, 2), 0) / returns1.length;
    const variance2 =
      returns2.reduce((sum, r) => sum + Math.pow(r - avgReturn2, 2), 0) / returns2.length;

    const volatility1 = Math.sqrt(variance1);
    const volatility2 = Math.sqrt(variance2);

    return {
      symbol1: symbol1.replace(".NS", ""),
      symbol2: symbol2.replace(".NS", ""),
      name1: company1?.name || symbol1,
      name2: company2?.name || symbol2,
      correlation,
      data1: alignedData1,
      data2: alignedData2,
      performance1: {
        return30d: return30d1,
        volatility: volatility1,
      },
      performance2: {
        return30d: return30d2,
        volatility: volatility2,
      },
    };
  } catch (error) {
    console.error(`Error comparing stocks ${symbol1} and ${symbol2}:`, error);
    return null;
  }
}

export async function fetchTopMovers(): Promise<{
  gainers: TopMover[];
  losers: TopMover[];
}> {
  try {
    const companies = await fetchCompaniesWithPrices();
    const movers = companies.filter((c) => c.changePercent !== undefined && c.currentPrice !== undefined);

    if (movers.length === 0) {
      console.warn("No movers data available");
      return { gainers: [], losers: [] };
    }

    movers.sort((a, b) => (b.changePercent || 0) - (a.changePercent || 0));

    const gainers: TopMover[] = movers
      .slice(0, 5)
      .filter((c) => (c.changePercent || 0) > 0)
      .map((c) => ({
        symbol: c.symbol,
        name: c.name,
        currentPrice: c.currentPrice || 0,
        change: c.change || 0,
        changePercent: c.changePercent || 0,
        volume: 0,
      }));

    const losers: TopMover[] = movers
      .slice(-5)
      .reverse()
      .filter((c) => (c.changePercent || 0) < 0)
      .map((c) => ({
        symbol: c.symbol,
        name: c.name,
        currentPrice: c.currentPrice || 0,
        change: c.change || 0,
        changePercent: c.changePercent || 0,
        volume: 0,
      }));

    return { gainers, losers };
  } catch (error) {
    console.error("Error fetching top movers:", error);
    return { gainers: [], losers: [] };
  }
}
