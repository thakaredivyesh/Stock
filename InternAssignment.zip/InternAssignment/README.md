# Stock Data Intelligence Dashboard

A professional financial data platform for analyzing NSE/BSE stock market data with real-time insights, advanced analytics, and interactive visualizations.

## 🎯 Overview

This full-stack application demonstrates comprehensive stock market data analytics with:
- **Real-time stock data** from Yahoo Finance API for NSE/BSE companies
- **Advanced metrics** including 52-week high/low, moving averages, and volatility scores
- **Interactive charts** powered by Chart.js with customizable time ranges
- **Stock comparison** with correlation analysis
- **Top gainers/losers** tracking
- **Professional UI** following financial dashboard design principles

## 📊 Features

### Data Collection & Processing
- ✅ Fetches live stock data using Yahoo Finance API
- ✅ Handles missing values and data cleaning
- ✅ Calculates **Daily Return**: `(CLOSE - OPEN) / OPEN`
- ✅ Computes **7-day Moving Average**
- ✅ Tracks **52-week High/Low**
- ✅ Custom **Volatility Score** metric
- ✅ Stock **Correlation Analysis**

### REST API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/companies` | GET | Returns list of all available NSE companies with current prices |
| `/api/data/:symbol?range=<days>` | GET | Returns historical OHLC data (30/90/365 days or all) |
| `/api/summary/:symbol` | GET | Returns 52-week stats, volatility, and moving averages |
| `/api/compare?symbol1=X&symbol2=Y` | GET | Compares two stocks with correlation analysis |
| `/api/top-movers` | GET | Returns top 5 gainers and losers |

### Interactive Dashboard
- 📈 **Stock Charts** with 7-day moving average overlay
- 🎛️ **Time Range Filters**: 30 days, 90 days, 1 year, all-time
- 📊 **Metric Cards** displaying key statistics
- 🔍 **Search & Filter** companies in sidebar
- ⚖️ **Stock Comparison** with side-by-side charts
- 📉 **Top Movers** section highlighting market leaders

## 🛠️ Tech Stack

### Backend
- **Framework**: Express.js with TypeScript
- **Data Source**: Yahoo Finance API (yahoo-finance2)
- **Data Processing**: Custom analytics engine
- **Caching**: In-memory caching for performance
- **Validation**: Zod schemas

### Frontend
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter
- **Data Fetching**: TanStack Query (React Query)
- **Charts**: Chart.js with react-chartjs-2
- **UI Components**: Shadcn UI (Radix primitives)
- **Styling**: Tailwind CSS
- **Typography**: IBM Plex Sans & IBM Plex Mono

### Database
- **Storage**: In-memory storage with caching (300s TTL for data, 60s for movers)
- **Future**: PostgreSQL migration ready

## 🚀 Setup Instructions

### Prerequisites
- Node.js 20+
- npm or yarn

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd stock-intelligence-dashboard
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the development server**
   ```bash
   npm run dev
   ```

4. **Access the dashboard**
   - Open your browser to `http://localhost:5000`
   - The application will automatically fetch live stock data from Yahoo Finance

### Environment Variables
No environment variables required for basic operation. The app uses Yahoo Finance's public API.

## 📂 Project Structure

```
├── client/                   # Frontend React application
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   │   ├── app-sidebar.tsx       # Company list sidebar
│   │   │   ├── stock-chart.tsx       # Chart.js integration
│   │   │   ├── metric-card.tsx       # Statistics display
│   │   │   ├── time-range-filter.tsx # Time range selector
│   │   │   └── top-movers.tsx        # Gainers/losers display
│   │   ├── pages/           # Application pages
│   │   │   ├── dashboard.tsx         # Home page
│   │   │   ├── stock-detail.tsx      # Individual stock view
│   │   │   └── compare-stocks.tsx    # Comparison tool
│   │   ├── App.tsx          # Main app with routing
│   │   └── index.css        # Global styles
│   └── index.html
├── server/                  # Backend Express application
│   ├── routes.ts           # API endpoint definitions
│   ├── storage.ts          # In-memory data storage
│   └── utils/
│       └── stock-data.ts   # Yahoo Finance integration & analytics
├── shared/
│   └── schema.ts           # Shared TypeScript types and Zod schemas
├── design_guidelines.md    # UI/UX design specifications
└── README.md
```

## 🧮 Data Analytics & Calculations

### Daily Return
```typescript
dailyReturn = ((CLOSE - OPEN) / OPEN) * 100
```

### 7-Day Moving Average
```typescript
MA7 = sum(last7ClosePrices) / 7
```

### Volatility Score
Standard deviation of daily returns:
```typescript
volatility = sqrt(variance(dailyReturns))
```

### Correlation Coefficient
Pearson correlation between two stock price series:
```typescript
correlation = covariance(stock1, stock2) / (stdDev(stock1) * stdDev(stock2))
```

## 🎨 Design Principles

The dashboard follows professional financial UI/UX guidelines:
- **Data Density**: Optimized for rapid information scanning
- **Typography**: IBM Plex Sans for readability, monospace for numbers
- **Color Coding**: Green for gains, red for losses
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **Loading States**: Skeleton screens for smooth UX
- **Error Handling**: Graceful fallbacks with retry logic

## 📈 Key Features Showcase

### 1. Real-Time Data Collection
- Fetches live prices from Yahoo Finance for 10 major NSE companies
- Sequential processing with 300ms delays to prevent API throttling
- Caching layer reduces redundant API calls (5-minute TTL for data)

### 2. Advanced Analytics
- **52-Week High/Low**: Tracks yearly price extremes
- **Moving Averages**: 7-day and 30-day smoothed trends
- **Volatility Scoring**: Risk assessment metric
- **Correlation Analysis**: Statistical relationship between stocks

### 3. Interactive Visualizations
- **Line Charts**: Historical price movements with MA overlay
- **Time Range Filtering**: Switch between 30D, 90D, 1Y, All
- **Responsive Charts**: Adapts to screen size and theme
- **Tooltips**: Detailed price information on hover

### 4. Stock Comparison Tool
- Side-by-side chart comparison
- Correlation coefficient calculation
- Performance metrics (30-day returns, volatility)

## 🔧 API Usage Examples

### Get All Companies
```bash
curl http://localhost:5000/api/companies
```

Response:
```json
[
  {
    "symbol": "RELIANCE",
    "name": "Reliance Industries Ltd",
    "exchange": "NSE",
    "currentPrice": 2456.75,
    "change": 23.50,
    "changePercent": 0.97
  },
  ...
]
```

### Get Stock Data
```bash
curl http://localhost:5000/api/data/RELIANCE?range=90
```

### Get Summary Statistics
```bash
curl http://localhost:5000/api/summary/TCS
```

### Compare Two Stocks
```bash
curl "http://localhost:5000/api/compare?symbol1=RELIANCE&symbol2=TCS"
```

## 🧪 Testing

The application includes comprehensive error handling:
- ✅ API retry logic (2 retries)
- ✅ Loading states with skeleton screens
- ✅ Error messages with detailed feedback
- ✅ Empty state handling
- ✅ Rate limit management

## 🚀 Future Enhancements

Potential improvements for production:
- [ ] PostgreSQL database for historical data persistence
- [ ] WebSocket integration for real-time price updates
- [ ] ML-based price prediction (LSTM or linear regression)
- [ ] RSI and MACD technical indicators
- [ ] Export charts as PNG/PDF
- [ ] User watchlists and portfolios
- [ ] Email/SMS alerts for price targets
- [ ] Sector-wise analysis
- [ ] Dockerization for easy deployment

## 📊 Performance Optimizations

- **Caching Strategy**: 5-minute cache for stock data, 1-minute for movers
- **Batch Processing**: Fetches company data in batches of 5 to avoid rate limits
- **Request Throttling**: 200ms delay between API calls
- **Query Optimization**: TanStack Query handles caching and deduplication
- **Code Splitting**: Lazy loading for better initial load time

## 📝 Development Notes

### Data Source
Uses Yahoo Finance API via the `yahoo-finance2` npm package. Stock symbols follow the NSE format with `.NS` suffix (e.g., `RELIANCE.NS`).

### Error Handling
- Network failures are gracefully handled with retry logic
- Rate limiting is managed through batching and delays
- All API responses include proper error messages
- Frontend displays user-friendly error states

### Caching Strategy
- Companies list: 60 seconds
- Stock data: 300 seconds (5 minutes)
- Summary stats: 300 seconds
- Comparison data: 300 seconds
- Top movers: 60 seconds

## 👨‍💻 Author

Created as part of the Jarnox Software Internship Assignment

## 📄 License

MIT License - Free to use for educational and commercial purposes

---

**Note**: This dashboard uses public Yahoo Finance data for educational purposes. For production use, consider upgrading to a professional financial data API with guaranteed uptime and support.
