import { z } from "zod";

// Company Schema
export const companySchema = z.object({
  symbol: z.string(),
  name: z.string(),
  exchange: z.string().optional(),
  currentPrice: z.number().optional(),
  change: z.number().optional(),
  changePercent: z.number().optional(),
});

export type Company = z.infer<typeof companySchema>;

// Stock Data Point Schema (OHLC data)
export const stockDataPointSchema = z.object({
  date: z.string(),
  open: z.number(),
  high: z.number(),
  low: z.number(),
  close: z.number(),
  volume: z.number(),
  dailyReturn: z.number().optional(),
  movingAverage7: z.number().optional(),
});

export type StockDataPoint = z.infer<typeof stockDataPointSchema>;

// Stock Data Response Schema
export const stockDataSchema = z.object({
  symbol: z.string(),
  data: z.array(stockDataPointSchema),
});

export type StockData = z.infer<typeof stockDataSchema>;

// Summary Statistics Schema
export const summarySchema = z.object({
  symbol: z.string(),
  name: z.string(),
  currentPrice: z.number(),
  high52Week: z.number(),
  low52Week: z.number(),
  averageClose: z.number(),
  totalVolume: z.number(),
  volatilityScore: z.number(),
  dailyReturn: z.number(),
  movingAverage7: z.number().optional(),
  movingAverage30: z.number().optional(),
  priceChange30d: z.number().optional(),
  priceChangePercent30d: z.number().optional(),
});

export type Summary = z.infer<typeof summarySchema>;

// Comparison Schema
export const comparisonSchema = z.object({
  symbol1: z.string(),
  symbol2: z.string(),
  name1: z.string(),
  name2: z.string(),
  correlation: z.number(),
  data1: z.array(stockDataPointSchema),
  data2: z.array(stockDataPointSchema),
  performance1: z.object({
    return30d: z.number(),
    volatility: z.number(),
  }),
  performance2: z.object({
    return30d: z.number(),
    volatility: z.number(),
  }),
});

export type Comparison = z.infer<typeof comparisonSchema>;

// Top Movers Schema
export const topMoverSchema = z.object({
  symbol: z.string(),
  name: z.string(),
  currentPrice: z.number(),
  change: z.number(),
  changePercent: z.number(),
  volume: z.number(),
  sparklineData: z.array(z.number()).optional(),
});

export type TopMover = z.infer<typeof topMoverSchema>;

export const topMoversSchema = z.object({
  gainers: z.array(topMoverSchema),
  losers: z.array(topMoverSchema),
  lastUpdated: z.string(),
});

export type TopMovers = z.infer<typeof topMoversSchema>;

// Time Range Type
export type TimeRange = '30' | '90' | '365' | 'all';
